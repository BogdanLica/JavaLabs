public class Main {
	
	public static void main(String[] args)
	{
		ATM myATM = new ATM();	//create an object of type ATM
		myATM.go();
		
	}
	
}


